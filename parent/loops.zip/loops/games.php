

<?php 
  
    if(!session_id())
    {
        session_start();
    }

    // if($_SESSION["userType"]=='1')
    // {
    //     echo $_SESSION["userType"];
    //     exit();
    //     echo "<script> window.location.replace('../login_and_register/login.php'); </script>";

    // }


    
  include ("../dbconnect.php");
  $sql = "SELECT * FROM tb_loops where lp_id = 9 ";
  $result= mysqli_query($conn,$sql); 


?>
<?php include("../commonPHP/topNavBarCheck.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container {
        position: relative;
        overflow: hidden;
        width: 100%;
        padding-top: 56.25%; /* 16:9 Aspect Ratio (divide 9 by 16 = 0.5625) */
        }

        /* Then style the iframe to fit in the container div with full height and width */
        .responsive-iframe {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        width: 100%;
        height: 100%;
        }
    </style>
</head>
<body>

<div class="container">

<?php  
while ($row = $result->fetch_assoc()) {
?>
<iframe class="responsive-iframe" mozallowfullscreen="true" allow="autoplay; fullscreen"  
        src="<?php echo $row['lp_filepath'] ?>"
        style="border:0px #000000 none;" name="Pong: Star Wars Remix" scrolling="no" msallowfullscreen="true" allowfullscreen="true" 
        webkitallowfullscreen="true" allowtransparency="true" frameborder="0" marginheight="px" marginwidth="320px" >
    </iframe>

<?php }    ?>



<!-- <iframe class="responsive-iframe" mozallowfullscreen="true" allow="autoplay; fullscreen"  
        src="../assets/loops/games/unity_games2/index.html" 
        assets\loops\games
        style="border:0px #000000 none;" name="Pong: Star Wars Remix" scrolling="no" msallowfullscreen="true" allowfullscreen="true" 
        webkitallowfullscreen="true" allowtransparency="true" frameborder="0" marginheight="px" marginwidth="320px" >
    </iframe>

</div>  -->

<!-- <iframe class="responsive-iframe" mozallowfullscreen="true" allow="autoplay; fullscreen"  
        src="../assets/loops/games/unity_games2/index.html" 
        style="border:0px #000000 none;" name="Pong: Star Wars Remix" scrolling="no" msallowfullscreen="true" allowfullscreen="true" 
        webkitallowfullscreen="true" allowtransparency="true" frameborder="0" marginheight="px" marginwidth="320px" height="540px" width="960px">
    </iframe> -->


</body>
</html>    


